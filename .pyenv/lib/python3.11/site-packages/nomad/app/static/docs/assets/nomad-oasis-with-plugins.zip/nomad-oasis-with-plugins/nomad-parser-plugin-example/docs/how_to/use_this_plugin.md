# How to Use This Plugin

This plugin can be used in a NOMAD Oasis instalation..

## Add This Plugin to Your NOMAD instalation

Read the [NOMAD plugin documentation](https://nomad-lab.eu/prod/v1/staging/docs/plugins/plugins.html#add-a-plugin-to-your-nomad) for all details on how to deploy the plugin on your NOMAD instance.

!!! note "Attention"
    Please update the document with relevant information specific to your plugin.
